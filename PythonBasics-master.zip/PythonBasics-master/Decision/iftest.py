
var1 =int(input("Enter Year"))

if var1%4==0:
   print("Leap Year")

else:
    print("Not Leap Year")

print ("Good bye!")