import os

print(os.getcwd())

print(os.listdir(os.getcwd()))