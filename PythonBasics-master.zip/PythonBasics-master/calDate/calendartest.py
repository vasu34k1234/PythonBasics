import calendar

cal = calendar.month(2008, 1)
print("Here is the calendar:")
print (cal)