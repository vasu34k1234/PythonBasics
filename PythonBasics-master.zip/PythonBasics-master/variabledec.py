counter = 100
miles   = 1000.0
name    = "John"

print(counter)
print (miles)
print (name)