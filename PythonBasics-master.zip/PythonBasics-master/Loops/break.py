for letter in 'Kolaparthi':
   if letter == 'a':
      break #continue
   print('Current Letter :', letter)